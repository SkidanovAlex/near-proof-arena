use std::{collections::BTreeSet, sync::Arc};

use itertools::Itertools;
use openvm_cpu_backend::CpuBackend;
use openvm_stark_backend::{
    keygen::types::{MultiStarkProvingKey, MultiStarkVerifyingKey},
    prover::{AirProvingContext, DeviceDataTransporter, ProvingContext},
    test_utils::{
        default_test_params_small, test_system_params_small,
        test_system_params_small_with_poly_len, CachedFixture11, FibFixture, InteractionsFixture11,
        MixtureFixture, MixtureFixtureEnum, PreprocessedAndCachedFixture, PreprocessedFibFixture,
        SelfInteractionFixture, TestFixture,
    },
    AirRef, StarkEngine, SystemParams, TranscriptHistory,
};
use openvm_stark_sdk::{
    config::baby_bear_poseidon2::{
        default_duplex_sponge_recorder, default_duplex_sponge_validator, BabyBearPoseidon2Config,
        BabyBearPoseidon2CpuEngine, DuplexSponge, DuplexSpongeRecorder,
    },
    utils::setup_tracing_with_log_level,
};
use test_case::{test_case, test_matrix};
use tracing::Level;

use crate::system::{
    AggregationSubCircuit, CachedTraceCtx, VerifierConfig, VerifierSubCircuit, VerifierTraceGen,
};

pub const MAX_CONSTRAINT_DEGREE: usize = 4;

/// Creates test system params with all PoW bits set to zero.
fn test_system_params_zero_pow(l_skip: usize, n_stack: usize, k_whir: usize) -> SystemParams {
    let mut params = test_system_params_small(l_skip, n_stack, k_whir);
    params.whir.mu_pow_bits = 0;
    params.whir.folding_pow_bits = 0;
    params.whir.query_phase_pow_bits = 0;
    params
}

pub fn test_engine_small() -> BabyBearPoseidon2CpuEngine<DuplexSponge> {
    let mut params = test_system_params_small(2, 10, 3);
    params.max_constraint_degree = MAX_CONSTRAINT_DEGREE;
    BabyBearPoseidon2CpuEngine::new(params)
}

fn verifier_circuit_keygen<const MAX_NUM_PROOFS: usize>(
    engine: &BabyBearPoseidon2CpuEngine<DuplexSponge>,
    child_vk: &MultiStarkVerifyingKey<BabyBearPoseidon2Config>,
) -> (
    VerifierSubCircuit<MAX_NUM_PROOFS>,
    MultiStarkProvingKey<BabyBearPoseidon2Config>,
) {
    let circuit = VerifierSubCircuit::new(Arc::new(child_vk.clone()));
    let (pk, _vk) = engine.keygen(&circuit.airs());
    (circuit, pk)
}

fn debug(
    engine: &BabyBearPoseidon2CpuEngine<DuplexSponge>,
    airs: &[AirRef<BabyBearPoseidon2Config>],
    ctxs: Vec<AirProvingContext<CpuBackend<BabyBearPoseidon2Config>>>,
) {
    for (air_idx, air) in airs.iter().enumerate() {
        tracing::debug!(%air_idx, air_name = %air.name());
    }
    let ctx = ProvingContext::new(ctxs.into_iter().enumerate().collect());
    engine.debug(airs, &ctx);
}

fn run_test<const MAX_NUM_PROOFS: usize, Fx: TestFixture<BabyBearPoseidon2Config>>(
    fx: Fx,
    child_engine: &BabyBearPoseidon2CpuEngine<DuplexSponge>,
    parent_engine: &BabyBearPoseidon2CpuEngine<DuplexSponge>,
    num_proofs: usize,
) {
    assert!(num_proofs <= MAX_NUM_PROOFS);
    let (vk, proof) = fx.keygen_and_prove(child_engine);
    let (circuit, pk) = verifier_circuit_keygen::<MAX_NUM_PROOFS>(parent_engine, &vk);
    let vk_commit_data = circuit.commit_child_vk(parent_engine, &vk);
    let proofs: Vec<_> = (0..num_proofs).map(|_| proof.clone()).collect();
    let ctxs = circuit.generate_proving_ctxs_base(
        &vk,
        CachedTraceCtx::PcsData(vk_commit_data),
        &proofs,
        &(),
        default_duplex_sponge_recorder(),
    );
    debug(parent_engine, &circuit.airs(), ctxs);
    let ctxs = circuit.generate_proving_ctxs_base(
        &vk,
        CachedTraceCtx::PcsData(circuit.commit_child_vk(parent_engine, &vk)),
        &proofs,
        &(),
        default_duplex_sponge_recorder(),
    );
    let parent_vk = pk.get_vk();
    let d_pk = parent_engine.device().transport_pk_to_device(&pk);
    let outer = parent_engine
        .prove(
            &d_pk,
            ProvingContext::new(ctxs.into_iter().enumerate().collect()),
        )
        .unwrap();
    parent_engine.verify(&parent_vk, &outer).unwrap();
    use openvm_stark_backend::codec::Encode;
    let mut inner_bytes = Vec::new();
    proof.encode(&mut inner_bytes).unwrap();
    let mut outer_bytes = Vec::new();
    outer.encode(&mut outer_bytes).unwrap();
    println!(
        "NEARPROOF_CHILD_BYTES={} NEARPROOF_PARENT_BYTES={}",
        inner_bytes.len(),
        outer_bytes.len()
    );
}

#[test_matrix(
    [2,3],
    [8,5],
    [3],
    [0,1,3,5,8]
)]
fn test_recursion_circuit_single_fib(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_degree: usize,
) {
    if log_trace_degree > l_skip + n_stack {
        return;
    }
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 1);
}

#[test]
fn test_recursion_circuit_many_fib_airs() {
    let params = test_system_params_small(3, 5, 3);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << 8, 9);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 1);
}

#[test]
fn test_recursion_circuit_many_fib_airs_some_missing() {
    let l_skip = 3;
    let n_stack = 5;
    let k_whir = 3;
    let log_trace_degree = 8;

    if log_trace_degree > l_skip + n_stack {
        return;
    }
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let empty_air_indices = vec![1, 3, 6];
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << log_trace_degree, 9)
        .with_empty_air_indices(empty_air_indices.clone());
    let (vk, proof) = fib.keygen_and_prove(&child_engine);

    let empty_air_indices = empty_air_indices.into_iter().collect::<BTreeSet<_>>();
    for air_idx in 0..vk.inner.per_air.len() {
        if empty_air_indices.contains(&air_idx) {
            assert!(
                !vk.inner.per_air[air_idx].is_required,
                "air {air_idx} unexpectedly marked required"
            );
            assert!(proof.trace_vdata[air_idx].is_none());
            assert!(proof.public_values[air_idx].is_empty());
        } else {
            assert!(proof.trace_vdata[air_idx].is_some());
        }
    }

    let parent_engine = test_engine_small();
    let (circuit, _pk) = verifier_circuit_keygen::<2>(&parent_engine, &vk);
    let vk_commit_data = circuit.commit_child_vk(&parent_engine, &vk);
    let ctxs = circuit.generate_proving_ctxs_base(
        &vk,
        CachedTraceCtx::PcsData(vk_commit_data),
        &[proof],
        &(),
        default_duplex_sponge_recorder(),
    );
    debug(&parent_engine, &circuit.airs(), ctxs);
}

#[test_case(2, 8, 3)]
#[test_case(5, 5, 4)]
#[test_case(5, 6, 4)]
#[test_case(6, 6, 5)]
fn test_recursion_circuit_interactions(l_skip: usize, n_stack: usize, k_whir: usize) {
    setup_tracing_with_log_level(Level::DEBUG);
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    run_test::<2, _>(InteractionsFixture11, &child_engine, &parent_engine, 1);
}

#[test_case(2, 8, 3, 5)]
#[test_case(3, 5, 3, 5)]
#[test_case(3, 5, 3, 1)]
fn test_preflight_single_fib_sponge(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_degree: usize,
) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let engine = BabyBearPoseidon2CpuEngine::<DuplexSpongeRecorder>::new(params);
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    let (pk, vk) = fib.keygen(&engine);

    let mut prover_sponge = default_duplex_sponge_recorder();
    let proof = fib.prove_from_transcript(&engine, &pk, &mut prover_sponge);
    let prover_sponge_len = prover_sponge.len();

    let preflight_sponge = default_duplex_sponge_validator(prover_sponge.into_log());
    let circuit = VerifierSubCircuit::<2>::new(Arc::new(vk.clone()));
    let preflight = circuit.run_preflight(preflight_sponge, &vk, &proof);
    assert_eq!(preflight.transcript.len(), prover_sponge_len);
}

#[test_case(2, 8, 3)]
#[test_case(5, 5, 4)]
#[test_case(5, 6, 4)]
fn test_preflight_cached_trace(l_skip: usize, n_stack: usize, k_whir: usize) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let fx = CachedFixture11::new(BabyBearPoseidon2Config::default_from_params(params));
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test_matrix(
    [2,3,5,6],
    [8,5],
    [3,4],
    [5,7,8,11]
)]
fn test_preflight_preprocessed_trace(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
) {
    if log_trace_height > l_skip + n_stack {
        return;
    }
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let height = 1 << log_trace_height;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = PreprocessedFibFixture::new(0, 1, sels);
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test_matrix(
    [2, 3, 5],
    [8],
    [3],
    [3, 4, 5]
)]
fn test_preflight_preprocessed_and_cached_trace(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let height = 1 << log_trace_height;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = MixtureFixture::new(vec![
        MixtureFixtureEnum::PreprocessedFibFixture(PreprocessedFibFixture::new(0, 1, sels)),
        MixtureFixtureEnum::CachedFixture11(CachedFixture11::new(
            BabyBearPoseidon2Config::default_from_params(params),
        )),
    ]);
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test_matrix(
    [2, 3, 5],
    [8],
    [3],
    [3, 4, 5],
    [1, 2]
)]
fn test_preflight_single_air_preprocessed_and_cached_trace(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
    num_cached_parts: usize,
) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let height = 1 << log_trace_height;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = PreprocessedAndCachedFixture::new(
        sels,
        BabyBearPoseidon2Config::default_from_params(params),
        num_cached_parts,
    );
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test_case(2, 8, 3, 5)]
#[test_case(3, 5, 3, 5)]
#[test_case(3, 5, 3, 1)]
fn test_preflight_multi_interaction_trace(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let fx = SelfInteractionFixture {
        widths: vec![4, 7, 8, 8, 10, 100],
        log_height: log_trace_height,
        bus_index: 4,
    };
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test_case(2, 8, 3, 5)]
#[test_case(3, 5, 3, 5)]
#[test_case(3, 5, 3, 1)]
fn test_preflight_mixture_trace(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let fx = MixtureFixture::standard(
        log_trace_height,
        BabyBearPoseidon2Config::default_from_params(params),
    );
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test]
fn test_preflight_preprocessed_and_cached_transcript() {
    let l_skip = 2;
    let n_stack = 8;
    let k_whir = 3;
    let log_trace_height = 4;
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let engine = BabyBearPoseidon2CpuEngine::<DuplexSpongeRecorder>::new(params.clone());
    let height = 1 << log_trace_height;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = MixtureFixture::new(vec![
        MixtureFixtureEnum::PreprocessedFibFixture(PreprocessedFibFixture::new(0, 1, sels)),
        MixtureFixtureEnum::CachedFixture11(CachedFixture11::new(
            BabyBearPoseidon2Config::default_from_params(params),
        )),
    ]);
    let (pk, vk) = fx.keygen(&engine);

    let mut prover_sponge = default_duplex_sponge_recorder();
    let proof = fx.prove_from_transcript(&engine, &pk, &mut prover_sponge);
    let prover_sponge_len = prover_sponge.len();

    let preflight_sponge = default_duplex_sponge_validator(prover_sponge.into_log());
    let circuit = VerifierSubCircuit::<2>::new(Arc::new(vk.clone()));
    let preflight = circuit.run_preflight(preflight_sponge, &vk, &proof);
    assert_eq!(preflight.transcript.len(), prover_sponge_len);
}

#[test]
fn test_preflight_interactions() {
    let params = default_test_params_small();
    let engine = BabyBearPoseidon2CpuEngine::<DuplexSpongeRecorder>::new(params);
    let fx = InteractionsFixture11;
    let (pk, vk) = fx.keygen(&engine);

    let mut prover_sponge = default_duplex_sponge_recorder();
    let proof = fx.prove_from_transcript(&engine, &pk, &mut prover_sponge);
    let prover_sponge_len = prover_sponge.len();

    let preflight_sponge = default_duplex_sponge_validator(prover_sponge.into_log());
    let circuit = VerifierSubCircuit::<2>::new(Arc::new(vk.clone()));
    let preflight = circuit.run_preflight(preflight_sponge, &vk, &proof);
    assert_eq!(preflight.transcript.len(), prover_sponge_len);
}

///////////////////////////////////////////////////////////////////////////////
// Multi-proof tests
///////////////////////////////////////////////////////////////////////////////

#[test_case(10 ; "fib log_height maximum (i.e. equals n_stack + l_skip)")]
#[test_case(3 ; "when fib log_height greater than l_skip")]
#[test_case(2 ; "when fib log_height equals l_skip")]
#[test_case(1 ; "when fib log_height less than l_skip")]
#[test_case(0 ; "when fib log_height is zero")]
fn test_recursion_circuit_two_fib_proofs(log_trace_degree: usize) {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 2);
}

#[test_case(10 ; "fib log_height maximum (i.e. equals n_stack + l_skip)")]
#[test_case(3 ; "when fib log_height greater than l_skip")]
#[test_case(2 ; "when fib log_height equals l_skip")]
#[test_case(1 ; "when fib log_height less than l_skip")]
#[test_case(0 ; "when fib log_height is zero")]
fn test_recursion_circuit_multiple_fib_proofs(log_trace_degree: usize) {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    run_test::<5, _>(fib, &child_engine, &parent_engine, 5);
}

#[test_matrix(
    [2,5,6],
    [8,5],
    [3,4],
    [4,8,11]
)]
fn test_recursion_circuit_two_preprocessed(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_height: usize,
) {
    let log_final_poly_len = (n_stack + l_skip) % k_whir + k_whir;
    if log_trace_height > l_skip + n_stack || log_final_poly_len >= l_skip + n_stack {
        return;
    }
    let params =
        test_system_params_small_with_poly_len(l_skip, n_stack, k_whir, log_final_poly_len, 3);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let height = 1 << log_trace_height;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = PreprocessedFibFixture::new(0, 1, sels);
    run_test::<2, _>(fx, &child_engine, &parent_engine, 2);
}

#[test_case(2, 8, 3)]
#[test_case(5, 5, 4)]
#[test_case(6, 5, 4)]
fn test_recursion_circuit_multiple_preprocessed(l_skip: usize, n_stack: usize, k_whir: usize) {
    let params = test_system_params_small(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    let height = 1 << 4;
    let sels = (0..height).map(|i| i % 2 == 0).collect_vec();
    let fx = PreprocessedFibFixture::new(0, 1, sels);
    run_test::<5, _>(fx, &child_engine, &parent_engine, 5);
}

#[test]
fn test_recursion_circuit_two_interactions() {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    run_test::<2, _>(InteractionsFixture11, &child_engine, &parent_engine, 2);
}

#[test]
fn test_recursion_circuit_multiple_interactions() {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    run_test::<5, _>(InteractionsFixture11, &child_engine, &parent_engine, 5);
}

#[test]
fn test_recursion_circuit_two_cached() {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let fx = CachedFixture11::new(BabyBearPoseidon2Config::default_from_params(params));
    run_test::<5, _>(fx, &child_engine, &parent_engine, 2);
}

#[test]
fn test_recursion_circuit_multiple_cached() {
    let params = default_test_params_small();
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let fx = CachedFixture11::new(BabyBearPoseidon2Config::default_from_params(params));
    run_test::<5, _>(fx, &child_engine, &parent_engine, 5);
}

#[test]
fn test_recursion_circuit_dag_commit_subair() {
    let params = test_system_params_small(3, 5, 3);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let parent_engine = test_engine_small();
    let fx = MixtureFixture::standard(
        5,
        BabyBearPoseidon2Config::default_from_params(params.clone()),
    );
    let (vk, proof) = fx.keygen_and_prove(&child_engine);

    let circuit = VerifierSubCircuit::<2>::new_with_options(
        Arc::new(vk.clone()),
        VerifierConfig {
            has_cached: false,
            ..Default::default()
        },
    );
    let cached_trace_record = <VerifierSubCircuit<2> as VerifierTraceGen<
        CpuBackend<BabyBearPoseidon2Config>,
        BabyBearPoseidon2Config,
        (),
    >>::cached_trace_record(&circuit, &vk);
    let ctxs = circuit.generate_proving_ctxs_base(
        &vk,
        CachedTraceCtx::Records(cached_trace_record),
        &[proof],
        &(),
        default_duplex_sponge_recorder(),
    );
    assert!(ctxs[0].cached_mains.is_empty());
    debug(&parent_engine, &circuit.airs(), ctxs);
}

///////////////////////////////////////////////////////////////////////////////
// NEGATIVE HYPERCUBE TESTS
///////////////////////////////////////////////////////////////////////////////
/// Negative hypercube refers to `n < 0`. These are still "positive" tests that are expected to
/// pass.
fn run_negative_hypercube_test<Fx: TestFixture<BabyBearPoseidon2Config>>(
    fx: Fx,
    mut params: SystemParams,
    num_proofs: usize,
) {
    params.l_skip += 3;
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    run_test::<5, _>(fx, &child_engine, &parent_engine, num_proofs);
}

#[test_case(1)]
#[test_case(4)]
fn test_neg_hypercube_fib(num_proofs: usize) {
    let params = default_test_params_small();
    let fx = FibFixture::new(0, 1, 1 << 3);
    run_negative_hypercube_test(fx, params, num_proofs);
}

#[test_case(1)]
#[test_case(4)]
fn test_neg_hypercube_cached(num_proofs: usize) {
    let params = default_test_params_small();
    // NOTE: the CachedFixture's cached trace needs correct params, run_negative_hypercube_test will
    // +3 to params.l_skip
    let mut fx_params = params.clone();
    fx_params.l_skip += 3;
    let fx = CachedFixture11::new(BabyBearPoseidon2Config::default_from_params(
        fx_params.clone(),
    ));
    run_negative_hypercube_test(fx, params, num_proofs);
}

#[test_case(1)]
#[test_case(4)]
fn test_neg_hypercube_preprocessed(num_proofs: usize) {
    let params = default_test_params_small();
    let sels = (0..(1 << 4)).map(|i| i % 2 == 0).collect_vec();
    let fx = PreprocessedFibFixture::new(0, 1, sels);
    run_negative_hypercube_test(fx, params, num_proofs);
}

#[test_case(1)]
#[test_case(4)]
fn test_neg_hypercube_multi_interaction(num_proofs: usize) {
    let params = default_test_params_small();
    let fx = SelfInteractionFixture {
        widths: vec![4, 7, 8, 8, 10, 100],
        log_height: 3,
        bus_index: 4,
    };
    run_negative_hypercube_test(fx, params, num_proofs);
}

#[test_case(1)]
#[test_case(4)]
fn test_neg_hypercube_mixture(num_proofs: usize) {
    let params = default_test_params_small();
    // NOTE: the CachedFixture's cached trace needs correct params, run_negative_hypercube_test will
    // +3 to params.l_skip
    let mut fx_params = params.clone();
    fx_params.l_skip += 3;
    let fx = MixtureFixture::standard(3, BabyBearPoseidon2Config::default_from_params(fx_params));
    run_negative_hypercube_test(fx, params, num_proofs);
}

///////////////////////////////////////////////////////////////////////////////
// ZERO POW BITS TESTS
///////////////////////////////////////////////////////////////////////////////

#[test_case(2, 8, 3, 5)]
#[test_case(3, 5, 3, 5)]
fn test_recursion_circuit_zero_pow_bits(
    l_skip: usize,
    n_stack: usize,
    k_whir: usize,
    log_trace_degree: usize,
) {
    let child_params = test_system_params_zero_pow(l_skip, n_stack, k_whir);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(child_params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 1);
}

#[test_case(5)]
fn test_recursion_circuit_zero_pow_bits_two_proofs(log_trace_degree: usize) {
    let child_params = test_system_params_zero_pow(2, 8, 3);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(child_params);
    let parent_engine = test_engine_small();
    let fib = FibFixture::new(0, 1, 1 << log_trace_degree);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 2);
}

///////////////////////////////////////////////////////////////////////////////
// EXACT W_STACK TESTS (no padding rows in StackingClaims)
///////////////////////////////////////////////////////////////////////////////

#[test]
fn test_recursion_circuit_exact_w_stack() {
    let fx = SelfInteractionFixture {
        widths: vec![4, 7, 8, 8, 10, 100],
        log_height: 5,
        bus_index: 4,
    };
    let mut params = test_system_params_small(2, 8, 3);
    // Determine the actual number of stacking claims, then set w_stack to match exactly.
    let engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
    let (_, proof) = fx.keygen_and_prove(&engine);
    let num_stacking_cols: usize = proof
        .stacking_proof
        .stacking_openings
        .iter()
        .map(|v| v.len())
        .sum();
    params.w_stack = num_stacking_cols;

    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let parent_engine = test_engine_small();
    run_test::<2, _>(fx, &child_engine, &parent_engine, 1);
}

#[test]
#[should_panic(expected = "StackingClaimsAir")]
fn test_recursion_circuit_w_stack_too_small() {
    let fx = SelfInteractionFixture {
        widths: vec![4, 7, 8, 8, 10, 100],
        log_height: 5,
        bus_index: 4,
    };
    let params = test_system_params_small(2, 8, 3);
    let child_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
    let (vk, proof) = fx.keygen_and_prove(&child_engine);
    let parent_engine = test_engine_small();

    // Generate traces with original (large) w_stack so tracegen succeeds.
    let circuit = VerifierSubCircuit::<2>::new(Arc::new(vk.clone()));
    let vk_commit_data = circuit.commit_child_vk(&parent_engine, &vk);
    let ctxs = circuit.generate_proving_ctxs_base(
        &vk,
        CachedTraceCtx::PcsData(vk_commit_data),
        std::slice::from_ref(&proof),
        &(),
        default_duplex_sponge_recorder(),
    );

    // Shrink w_stack below the actual number of stacking claims.
    let mut small_vk = vk;
    let num_stacking_cols: usize = proof
        .stacking_proof
        .stacking_openings
        .iter()
        .map(|v| v.len())
        .sum();
    small_vk.inner.params.w_stack = num_stacking_cols - 1;

    // Re-create circuit with small w_stack: AIR constraints use the smaller bound.
    let circuit_small = VerifierSubCircuit::<2>::new(Arc::new(small_vk));
    debug(&parent_engine, &circuit_small.airs(), ctxs);
}

///////////////////////////////////////////////////////////////////////////////
// CUDA TRACEGEN TESTS
///////////////////////////////////////////////////////////////////////////////
#[cfg(feature = "cuda")]
mod cuda {
    use itertools::zip_eq;
    use openvm_cuda_backend::{prelude::SC, BabyBearPoseidon2GpuEngine};
    use openvm_cuda_common::copy::MemCopyD2H;
    use openvm_stark_backend::prover::MatrixDimensions;
    #[cfg(feature = "touchemall")]
    use openvm_stark_sdk::config::baby_bear_poseidon2::F;
    use openvm_stark_sdk::{
        config::baby_bear_poseidon2::BabyBearPoseidon2RefEngine,
        utils::setup_tracing_with_log_level,
    };
    use test_case::test_matrix;
    use tracing::Level;

    use super::*;

    /// `params` are system parameters of the parent.
    fn compare_cpu_tracegen_vs_gpu_tracegen<Fx: TestFixture<BabyBearPoseidon2Config>>(
        fx: Fx,
        params: SystemParams,
        num_proofs: usize,
    ) {
        setup_tracing_with_log_level(Level::INFO);
        // Use reference engine for the test fixture to remove any testing dependence on the
        // cpu backend prover.
        let ref_engine = BabyBearPoseidon2RefEngine::<DuplexSponge>::new(params.clone());
        let cpu_engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params.clone());
        let gpu_engine = BabyBearPoseidon2GpuEngine::new(params);
        let gpu_device_ctx = gpu_engine.device().device_ctx.clone();
        let (pk, vk) = fx.keygen(&ref_engine);
        assert!(num_proofs <= 5);
        let proofs = (0..num_proofs)
            .map(|_| fx.prove(&ref_engine, &pk))
            .collect_vec();
        let vk = Arc::new(vk);

        let circuit = VerifierSubCircuit::<5>::new(vk.clone());
        for (air_idx, air) in circuit.airs::<SC>().iter().enumerate() {
            tracing::debug!(%air_idx, air_name = %air.name());
        }

        let vk_commit_data_cpu = circuit.commit_child_vk(&cpu_engine, &vk);
        let vk_commit_data_gpu = circuit.commit_child_vk(&gpu_engine, &vk);
        let cpu_ctx = circuit.generate_proving_ctxs_base(
            &vk,
            CachedTraceCtx::PcsData(vk_commit_data_cpu),
            &proofs,
            &(),
            default_duplex_sponge_recorder(),
        );
        let gpu_proving_ctxs = circuit.generate_proving_ctxs_base(
            &vk,
            CachedTraceCtx::PcsData(vk_commit_data_gpu),
            &proofs,
            &gpu_device_ctx,
            default_duplex_sponge_recorder(),
        );

        #[cfg(feature = "touchemall")]
        for (i, gpu) in gpu_proving_ctxs.iter().enumerate() {
            let gpu = &gpu.common_main;
            let name = circuit.airs::<SC>()[i].name();

            let width = gpu.width();
            let height = gpu.height();

            let gpu = gpu.to_host_on(&gpu_device_ctx).unwrap();

            for r in 0..height {
                for c in 0..width {
                    let val = gpu[c * height + r];
                    let val_32 = unsafe { *(&val as *const F as *const u32) };
                    assert!(
                        val_32 != 0xffffffff,
                        "potentially untouched value at ({r}, {c}) of a trace of size {height}x{width} for air {name}"
                    );
                }
            }
        }

        const POSEIDON2_AIR_ID: usize = 14;
        assert!(circuit.airs::<SC>()[POSEIDON2_AIR_ID]
            .name()
            .starts_with("Poseidon2Air"));

        let non_deterministic_air_idxs = [
            POSEIDON2_AIR_ID,
            cpu_ctx.len() - 1, // exp_bits is non-deterministic when multi-threaded
        ];

        for (i, (cpu, gpu)) in zip_eq(cpu_ctx, gpu_proving_ctxs).enumerate() {
            let cpu = cpu.common_main;
            let gpu = gpu.common_main;
            assert_eq!(gpu.width(), cpu.width(), "Width mismatch at AIR {i}");
            assert_eq!(gpu.height(), cpu.height(), "Height mismatch at AIR {i}");

            let name = circuit.airs::<SC>()[i].name();

            if non_deterministic_air_idxs.contains(&i) {
                continue;
            }
            let gpu = gpu.to_host_on(&gpu_device_ctx).unwrap();
            let cpu_height = cpu.height();
            let cpu_width = cpu.width();

            for r in 0..cpu_height {
                for c in 0..cpu_width {
                    assert_eq!(
                        gpu[c * cpu_height + r],
                        cpu.values[r * cpu_width + c],
                        "Mismatch for {} at row {r} column {c}",
                        name
                    );
                }
            }
        }
    }

    #[test_matrix(
        [2,3],
        [8,5],
        [3],
        [1,3,5],
        [1,4]
    )]
    fn test_cuda_tracegen_single_fib(
        l_skip: usize,
        n_stack: usize,
        k_whir: usize,
        log_trace_degree: usize,
        num_proofs: usize,
    ) {
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let fx = FibFixture::new(0, 1, 1 << log_trace_degree);
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }

    #[test_matrix(
        [2,3],
        [8],
        [3],
        [1,3,5],
        [1,4]
    )]
    fn test_cuda_tracegen_multiple_fib(
        l_skip: usize,
        n_stack: usize,
        k_whir: usize,
        log_trace_degree: usize,
        num_proofs: usize,
    ) {
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let empty_air_indices = vec![1, 3, 6];
        let fx = FibFixture::new_with_num_airs(0, 1, 1 << log_trace_degree, 9)
            .with_empty_air_indices(empty_air_indices);
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }

    #[test_matrix(
        [1,2,5],
        [5,8],
        [3,4],
        [1,4]
    )]
    fn test_cuda_tracegen_cached(l_skip: usize, n_stack: usize, k_whir: usize, num_proofs: usize) {
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let fx = CachedFixture11::new(BabyBearPoseidon2Config::default_from_params(params.clone()));
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }

    #[test_matrix(
        [1,2,5],
        [5,8],
        [3,4],
        [1,3,5],
        [1,4]
    )]
    fn test_cuda_tracegen_preprocessed(
        l_skip: usize,
        n_stack: usize,
        k_whir: usize,
        log_trace_degree: usize,
        num_proofs: usize,
    ) {
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let sels = (0..(1 << log_trace_degree))
            .map(|i| i % 2 == 0)
            .collect_vec();
        let fx = PreprocessedFibFixture::new(0, 1, sels);
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }

    #[test_matrix(
        [1,2,5],
        [3,4],
        [1,3,5],
        [1,4]
    )]
    fn test_cuda_tracegen_multi_interaction(
        l_skip: usize,
        k_whir: usize,
        log_trace_degree: usize,
        num_proofs: usize,
    ) {
        let n_stack = 12 - l_skip;
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let fx = SelfInteractionFixture {
            widths: vec![4, 7, 8, 8, 10, 100],
            log_height: log_trace_degree,
            bus_index: 4,
        };
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }

    #[test_matrix(
        [1,2,5],
        [3,4],
        [1,3,5],
        [1,4]
    )]
    fn test_cuda_tracegen_mixture(
        l_skip: usize,
        k_whir: usize,
        log_trace_degree: usize,
        num_proofs: usize,
    ) {
        let n_stack = 12 - l_skip;
        let params = test_system_params_small(l_skip, n_stack, k_whir);
        let fx = MixtureFixture::standard(
            log_trace_degree,
            BabyBearPoseidon2Config::default_from_params(params.clone()),
        );
        compare_cpu_tracegen_vs_gpu_tracegen(fx, params, num_proofs);
    }
}

#[test]
fn nearproof_recursion_production_parameters() {
    use openvm_stark_sdk::config::{
        app_params_with_100_bits_security, leaf_params_with_100_bits_security,
    };
    let child_engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(app_params_with_100_bits_security(12));
    let parent_engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(leaf_params_with_100_bits_security());
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << 8, 9);
    run_test::<2, _>(fib, &child_engine, &parent_engine, 1);
}

#[test]
fn nearproof_recursive_chain() {
    use openvm_stark_backend::{codec::Encode, prover::MatrixDimensions};
    use openvm_stark_sdk::config::{
        app_params_with_100_bits_security, baby_bear_poseidon2::F,
        internal_params_with_100_bits_security, leaf_params_with_100_bits_security,
        root_params_with_100_bits_security,
    };
    use p3_field::PrimeCharacteristicRing;
    use p3_matrix::dense::RowMajorMatrix;
    let child_engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(app_params_with_100_bits_security(12));
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << 8, 9);
    let (mut child_vk, mut child_proof) = fib.keygen_and_prove(&child_engine);
    for (name, params) in [
        ("leaf", leaf_params_with_100_bits_security()),
        ("internal", internal_params_with_100_bits_security()),
        (
            "root_geometry_babybear_hash",
            root_params_with_100_bits_security(),
        ),
    ] {
        let engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
        let no_cache = name == "root_geometry_babybear_hash"
            && std::env::var_os("NEARPROOF_DAG_COMMIT").is_some();
        let circuit = VerifierSubCircuit::<2>::new_with_options(
            Arc::new(child_vk.clone()),
            VerifierConfig {
                has_cached: !no_cache,
                ..Default::default()
            },
        );
        let (mut pk, _) = engine.keygen(&circuit.airs());
        let cache_ctx = if no_cache {
            let record = <VerifierSubCircuit<2> as VerifierTraceGen<
                CpuBackend<BabyBearPoseidon2Config>,
                BabyBearPoseidon2Config,
                (),
            >>::cached_trace_record(&circuit, &child_vk);
            CachedTraceCtx::Records(record)
        } else {
            CachedTraceCtx::PcsData(circuit.commit_child_vk(&engine, &child_vk))
        };
        let mut ctxs = circuit.generate_proving_ctxs_base(
            &child_vk,
            cache_ctx,
            &[child_proof],
            &(),
            default_duplex_sponge_recorder(),
        );
        let mut airs = circuit.airs::<BabyBearPoseidon2Config>();
        let split = name == "root_geometry_babybear_hash"
            && std::env::var_os("NEARPROOF_SPLIT_HASH").is_some();
        let name = if split { "root_split_hash" } else { name };
        if split {
            let idx = airs
                .iter()
                .position(|air| air.name().starts_with("Poseidon2Air<"))
                .unwrap();
            let original = &ctxs[idx];
            assert!(original.cached_mains.is_empty() && original.public_values.is_empty());
            let matrix = &original.common_main;
            let width = matrix.width();
            let live = matrix
                .values
                .chunks_exact(width)
                .rposition(|row| row[width - 2] != F::ZERO || row[width - 1] != F::ZERO)
                .unwrap()
                + 1;
            let first_height = 1usize << live.ilog2();
            assert!(live > first_height);
            let second_height = (live - first_height).next_power_of_two();
            assert!(first_height + second_height <= matrix.height());
            // Reuse valid zero-multiplicity padding rows; do not fabricate all-zero permutations.
            for row in matrix.values[(first_height + second_height) * width..].chunks_exact(width) {
                assert_eq!(row[width - 2], F::ZERO);
                assert_eq!(row[width - 1], F::ZERO);
            }
            let first = RowMajorMatrix::new(matrix.values[..first_height * width].to_vec(), width);
            let second = RowMajorMatrix::new(
                matrix.values[first_height * width..(first_height + second_height) * width]
                    .to_vec(),
                width,
            );
            println!("NEARPROOF_SPLIT live={live} original={} first={first_height} second={second_height}", matrix.height());
            ctxs[idx].common_main = first;
            ctxs.push(AirProvingContext {
                cached_mains: vec![],
                common_main: second,
                public_values: vec![],
            });
            airs.push(airs[idx].clone());
            (pk, _) = engine.keygen(&airs);
        }
        let mut common_cells = 0;
        let mut cached_cells = 0;
        for (air, ctx) in airs.iter().zip(&ctxs) {
            let height = ctx.common_main.height();
            let width = ctx.common_main.width();
            common_cells += height * width;
            for cached in &ctx.cached_mains {
                cached_cells += cached.trace.height() * cached.trace.width();
            }
            println!(
                "NEARPROOF_TRACE stage={name} air={} height={height} width={width}",
                air.name()
            );
        }
        println!("NEARPROOF_CELLS stage={name} common={common_cells} cached={cached_cells}");
        let ctx = ProvingContext::new(ctxs.into_iter().enumerate().collect());
        engine.debug(&airs, &ctx);
        if no_cache && std::env::var_os("NEARPROOF_TRACE_ONLY").is_some() {
            println!("NEARPROOF_DAG_TRACE_ONLY debug=passed");
            break;
        }
        let d_pk = engine.device().transport_pk_to_device(&pk);
        let proof = engine.prove(&d_pk, ctx).unwrap();
        let vk = pk.get_vk();
        engine.verify(&vk, &proof).unwrap();
        let mut bytes = Vec::new();
        proof.encode(&mut bytes).unwrap();
        println!("NEARPROOF_CHAIN stage={name} bytes={}", bytes.len());
        for (label, count) in [
            ("gkr", {
                let mut b = Vec::new();
                proof.gkr_proof.encode(&mut b).unwrap();
                b.len()
            }),
            ("constraints", {
                let mut b = Vec::new();
                proof.batch_constraint_proof.encode(&mut b).unwrap();
                b.len()
            }),
            ("stacking", {
                let mut b = Vec::new();
                proof.stacking_proof.encode(&mut b).unwrap();
                b.len()
            }),
            ("whir", {
                let mut b = Vec::new();
                proof.whir_proof.encode(&mut b).unwrap();
                b.len()
            }),
        ] {
            println!("NEARPROOF_PART stage={name} part={label} bytes={count}");
        }
        std::fs::write(format!("/tmp/nearproof-chain-{name}.proof"), bytes).unwrap();
        child_vk = vk;
        child_proof = proof;
    }
}

#[test]
fn nearproof_wire_census() {
    use openvm_stark_backend::{
        codec::{Decode, Encode},
        proof::Proof,
    };
    for stage in [
        "leaf",
        "internal",
        "root_geometry_babybear_hash",
        "root_split_hash",
    ] {
        let bytes = std::fs::read(format!("/tmp/nearproof-chain-{stage}.proof")).unwrap();
        let mut reader = &bytes[..];
        let p = Proof::<BabyBearPoseidon2Config>::decode(&mut reader).unwrap();
        assert!(reader.is_empty());
        let mut encoded = Vec::new();
        p.encode(&mut encoded).unwrap();
        assert_eq!(bytes, encoded);
        let opening = &p.whir_proof;
        let first_q = opening.initial_round_opened_rows[0].len();
        let first_base_per_query: usize = opening
            .initial_round_opened_rows
            .iter()
            .map(|c| c[0].iter().map(Vec::len).sum::<usize>())
            .sum();
        let later_q: Vec<_> = opening
            .codeword_opened_values
            .iter()
            .map(Vec::len)
            .collect();
        let later_values: Vec<_> = opening
            .codeword_opened_values
            .iter()
            .map(|r| r[0].len())
            .collect();
        println!("NEARPROOF_QUERY_SHAPE stage={stage} first_q={first_q} first_base_per_query={first_base_per_query} later_q={later_q:?} later_values={later_values:?}");
        let g = &p.gkr_proof;
        let b = &p.batch_constraint_proof;
        let s = &p.stacking_proof;
        let w = &p.whir_proof;
        let g_ef = 1
            + 4 * g.claims_per_layer.len()
            + g.sumcheck_polys.iter().map(|r| 3 * r.len()).sum::<usize>();
        let column_ef = b
            .column_openings
            .iter()
            .flatten()
            .map(Vec::len)
            .sum::<usize>();
        println!("NEARPROOF_COLUMNS stage={stage} column_ef={column_ef}");
        let b_ef = b.numerator_term_per_air.len()
            + b.denominator_term_per_air.len()
            + b.univariate_round_coeffs.len()
            + b.sumcheck_round_polys.iter().map(Vec::len).sum::<usize>()
            + b.column_openings
                .iter()
                .flatten()
                .map(Vec::len)
                .sum::<usize>();
        let s_ef = s.univariate_round_coeffs.len()
            + 2 * s.sumcheck_round_polys.len()
            + s.stacking_openings.iter().map(Vec::len).sum::<usize>();
        let w_ef = 2 * w.whir_sumcheck_polys.len()
            + w.ood_values.len()
            + w.codeword_opened_values
                .iter()
                .flatten()
                .map(Vec::len)
                .sum::<usize>()
            + w.final_poly.len();
        let ef = g_ef + b_ef + s_ef + w_ef;
        let bf = p.public_values.iter().map(Vec::len).sum::<usize>()
            + 2
            + w.folding_pow_witnesses.len()
            + w.query_phase_pow_witnesses.len()
            + w.initial_round_opened_rows
                .iter()
                .flatten()
                .flatten()
                .map(Vec::len)
                .sum::<usize>();
        let digests = 1
            + p.trace_vdata
                .iter()
                .flatten()
                .map(|t| t.cached_commitments.len())
                .sum::<usize>()
            + w.codeword_commits.len()
            + w.initial_round_merkle_proofs
                .iter()
                .flatten()
                .map(Vec::len)
                .sum::<usize>()
            + w.codeword_merkle_proofs
                .iter()
                .flatten()
                .map(Vec::len)
                .sum::<usize>();
        use openvm_stark_backend::codec::EncodableConfig;
        let digest_refs = std::iter::once(&p.common_main_commit)
            .chain(
                p.trace_vdata
                    .iter()
                    .flatten()
                    .flat_map(|t| t.cached_commitments.iter()),
            )
            .chain(w.codeword_commits.iter())
            .chain(w.initial_round_merkle_proofs.iter().flatten().flatten())
            .chain(w.codeword_merkle_proofs.iter().flatten().flatten());
        let mut unique = std::collections::HashSet::new();
        let mut seen = 0;
        for d in digest_refs {
            let mut b = Vec::new();
            BabyBearPoseidon2Config::encode_digest(d, &mut b).unwrap();
            unique.insert(b);
            seen += 1;
        }
        assert_eq!(seen, digests);
        println!(
            "NEARPROOF_DIGESTS stage={stage} unique={} occurrences={digests}",
            unique.len()
        );
        let framing = bytes
            .len()
            .checked_sub(16 * ef + 4 * bf + 32 * digests)
            .unwrap();
        assert!(framing < 4096);
        println!("NEARPROOF_CENSUS stage={stage} bytes={} ef={ef} bf={bf} digests={digests} framing={framing} gkr_ef={g_ef} constraints_ef={b_ef} stacking_ef={s_ef} whir_ef={w_ef}",bytes.len());
    }
}

#[test]
fn nearproof_fixed_dag_census() {
    use openvm_stark_backend::air_builders::symbolic::SymbolicExpressionNode as N;
    use openvm_stark_sdk::config::{
        app_params_with_100_bits_security, internal_params_with_100_bits_security,
        leaf_params_with_100_bits_security,
    };
    let engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(app_params_with_100_bits_security(12));
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << 8, 9);
    let (mut vk, _) = fib.keygen_and_prove(&engine);
    for params in [
        leaf_params_with_100_bits_security(),
        internal_params_with_100_bits_security(),
    ] {
        let e = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(params);
        let (_, pk) = verifier_circuit_keygen::<2>(&e, &vk);
        vk = pk.get_vk();
    }
    nearproof_export_fixed_dag(&vk);
    if let Ok(path) = std::env::var("NEARPROOF_EXPORT_OPENINGS") {
        nearproof_export_openings(&vk, &path);
    }
    let mut totals = std::collections::BTreeMap::<&str, usize>::new();
    for (i, air) in vk.inner.per_air.iter().enumerate() {
        let nodes = &air.symbolic_constraints.constraints.nodes;
        let mut counts = std::collections::BTreeMap::<&str, usize>::new();
        for (idx, node) in nodes.iter().enumerate() {
            let label = match node {
                N::Variable(_) => "variable",
                N::Constant(_) => "constant",
                N::Add {
                    left_idx,
                    right_idx,
                    ..
                } => {
                    assert!(*left_idx < idx && *right_idx < idx);
                    "add"
                }
                N::Sub {
                    left_idx,
                    right_idx,
                    ..
                } => {
                    assert!(*left_idx < idx && *right_idx < idx);
                    "sub"
                }
                N::Neg { idx: operand, .. } => {
                    assert!(*operand < idx);
                    "neg"
                }
                N::Mul {
                    left_idx,
                    right_idx,
                    ..
                } => {
                    assert!(*left_idx < idx && *right_idx < idx);
                    match (
                        matches!(nodes[*left_idx], N::Constant(_)),
                        matches!(nodes[*right_idx], N::Constant(_)),
                    ) {
                        (true, true) => "mul_constant_constant",
                        (true, false) | (false, true) => "mul_base_constant",
                        (false, false) => "mul_dynamic",
                    }
                }
                N::IsFirstRow => "first_row",
                N::IsLastRow => "last_row",
                N::IsTransition => "transition",
            };
            *counts.entry(label).or_default() += 1;
            *totals.entry(label).or_default() += 1;
        }
        assert_eq!(counts.values().sum::<usize>(), nodes.len());
        println!(
            "NEARPROOF_DAG air={i} nodes={} counts={counts:?}",
            nodes.len()
        );
    }
    println!(
        "NEARPROOF_DAG_TOTAL airs={} nodes={} counts={totals:?}",
        vk.inner.per_air.len(),
        totals.values().sum::<usize>()
    );
}

fn nearproof_export_fixed_dag(vk: &MultiStarkVerifyingKey<BabyBearPoseidon2Config>) {
    use openvm_stark_backend::air_builders::symbolic::{
        symbolic_expression::SymbolicEvaluator,
        symbolic_variable::{Entry, SymbolicVariable},
        SymbolicExpressionNode as N,
    };
    use openvm_stark_sdk::config::baby_bear_poseidon2::F;
    use p3_field::{PrimeCharacteristicRing, PrimeField32};
    fn binding(v: SymbolicVariable<F>) -> (u32, usize, usize, usize) {
        match v.entry {
            Entry::Preprocessed { offset } => (0, 0, offset, v.index),
            Entry::Main { part_index, offset } => (1, part_index, offset, v.index),
            Entry::Public => (2, 0, 0, v.index),
            Entry::Challenge => (3, 0, 0, v.index),
        }
    }
    struct Eval(u32);
    impl SymbolicEvaluator<F, F> for Eval {
        fn eval_const(&self, c: F) -> F {
            c
        }
        fn eval_var(&self, v: SymbolicVariable<F>) -> F {
            let (k, p, o, i) = binding(v);
            F::from_u64(
                (self.0 as u64 + 1)
                    * (1 + k as u64 * 100003 + p as u64 * 1009 + o as u64 * 97 + i as u64 * 7),
            )
        }
        fn eval_is_first_row(&self) -> F {
            F::from_u32(self.0 + 13)
        }
        fn eval_is_last_row(&self) -> F {
            F::from_u32(self.0 + 17)
        }
        fn eval_is_transition(&self) -> F {
            F::ONE - self.eval_is_last_row()
        }
    }
    let mut lines = Vec::new();
    for (air_id, air) in vk.inner.per_air.iter().enumerate() {
        let dag = &air.symbolic_constraints;
        let mut nodes = Vec::new();
        for node in &dag.constraints.nodes {
            nodes.push(match *node {
                N::Variable(v) => {
                    let (k, p, o, i) = binding(v);
                    format!("[\"variable\",{k},{p},{o},{i}]")
                }
                N::Constant(c) => format!("[\"const\",{}]", c.as_canonical_u32()),
                N::Add {
                    left_idx,
                    right_idx,
                    ..
                } => format!("[\"add\",{left_idx},{right_idx}]"),
                N::Sub {
                    left_idx,
                    right_idx,
                    ..
                } => format!("[\"sub\",{left_idx},{right_idx}]"),
                N::Mul {
                    left_idx,
                    right_idx,
                    ..
                } => format!("[\"mul\",{left_idx},{right_idx}]"),
                N::Neg { idx, .. } => format!("[\"neg\",{idx}]"),
                N::IsFirstRow => "[\"first_row\"]".to_string(),
                N::IsLastRow => "[\"last_row\"]".to_string(),
                N::IsTransition => "[\"transition\"]".to_string(),
            });
        }
        let cases = [0, 1, 123456].map(|seed| {
            let values = Eval(seed)
                .eval_nodes(&dag.constraints.nodes)
                .iter()
                .map(|x| x.as_canonical_u32())
                .collect_vec();
            format!("{{\"seed\":{seed},\"values\":{values:?}}}")
        });
        let interactions = dag
            .interactions
            .iter()
            .map(|x| {
                format!(
                    "{{\"bus\":{},\"count\":{},\"weight\":{},\"message\":{:?}}}",
                    x.bus_index, x.count, x.count_weight, x.message
                )
            })
            .collect_vec();
        lines.push(format!("{{\"air\":{air_id},\"nodes\":[{}],\"constraints\":{:?},\"interactions\":[{}],\"cases\":[{}]}}",nodes.join(","),dag.constraints.constraint_idx,interactions.join(","),cases.join(",")));
    }
    std::fs::write("/tmp/nearproof-fixed-dag.jsonl", lines.join("\n") + "\n").unwrap();
}

fn nearproof_export_openings(vk: &MultiStarkVerifyingKey<BabyBearPoseidon2Config>, path: &str) {
    use openvm_stark_backend::{
        codec::{Decode, Encode},
        proof::Proof,
    };
    use openvm_stark_sdk::config::baby_bear_poseidon2::{EF, F};
    use p3_field::BasedVectorSpace;
    let bytes = std::fs::read(path).unwrap();
    let mut reader = bytes.as_slice();
    let proof = Proof::<BabyBearPoseidon2Config>::decode(&mut reader).unwrap();
    assert!(reader.is_empty());
    let mut encoded = Vec::new();
    proof.encode(&mut encoded).unwrap();
    assert_eq!(encoded, bytes);
    let engine = BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(vk.inner.params.clone());
    engine.verify(vk, &proof).unwrap();
    let mut ids = (0..vk.inner.per_air.len())
        .filter(|&i| proof.trace_vdata[i].is_some())
        .collect_vec();
    ids.sort_by_key(|&i| {
        (
            std::cmp::Reverse(proof.trace_vdata[i].as_ref().unwrap().log_height),
            i,
        )
    });
    let enc = |xs: &[EF]| {
        format!(
            "[{}]",
            xs.iter()
                .map(|x| format!(
                    "{:?}",
                    <EF as BasedVectorSpace<F>>::as_basis_coefficients_slice(x)
                ))
                .join(",")
        )
    };
    let layouts =
        openvm_stark_backend::verifier::proof_shape::verify_proof_shape(&vk.inner, &proof).unwrap();
    let packed = layouts
        .iter()
        .map(|layout| {
            let slices = layout
                .sorted_cols
                .iter()
                .map(|(matrix, col, s)| {
                    format!(
                        "[{}, {}, {}, {}, {}]",
                        matrix,
                        col,
                        s.col_idx,
                        s.row_idx,
                        s.log_height()
                    )
                })
                .collect_vec();
            format!(
                "{{\"l_skip\":{},\"height\":{},\"width\":{},\"slices\":[{}]}}",
                layout.l_skip(),
                layout.height(),
                layout.width(),
                slices.join(",")
            )
        })
        .collect_vec();
    std::fs::write(
        "/tmp/nearproof-native-layouts.json",
        format!("[{}]\n", packed.join(",")),
    )
    .unwrap();
    let mut rows = Vec::new();
    for (trace, &air) in ids.iter().enumerate() {
        let key = &vk.inner.per_air[air];
        let openings = proof.batch_constraint_proof.column_openings[trace]
            .iter()
            .map(|x| enc(x))
            .collect_vec();
        rows.push(format!("{{\"air\":{air},\"trace\":{trace},\"need_rot\":{},\"has_preprocessed\":{},\"cached_count\":{},\"common_width\":{},\"parts\":[{}]}}",key.params.need_rot,key.preprocessed_data.is_some(),key.params.width.cached_mains.len(),key.params.width.common_main,openings.join(",")));
    }
    std::fs::write(
        "/tmp/nearproof-native-openings.json",
        format!("[{}]\n", rows.join(",")),
    )
    .unwrap();
    println!(
        "NEARPROOF_OPENINGS proof_bytes={} airs={} verified=true",
        bytes.len(),
        ids.len()
    );
}

#[test]
fn nearproof_weighted_stack_kernel_oracle() {
    use openvm_stark_backend::poly_common::{
        eval_eq_mle, eval_eq_prism, eval_in_uni, eval_rot_kernel_prism,
    };
    use openvm_stark_sdk::config::baby_bear_poseidon2::F;
    use p3_field::{PrimeCharacteristicRing, PrimeField32, TwoAdicField};
    let mut rows = Vec::new();
    for l in 1..=3 {
        let stack = l + 3;
        for height in 0..=l + 2 {
            for block in 0..2 {
                let n = height as isize - l as isize;
                let lift = n.max(0) as usize;
                let start = block * (1usize << height.max(l));
                let r = (0..4).map(|i| F::from_u32(13 + i * 7)).collect_vec();
                let u = (0..4).map(|i| F::from_u32(23 + i * 11)).collect_vec();
                let bits = (l + lift..stack)
                    .map(|j| F::from_bool((start >> j) & 1 == 1))
                    .collect_vec();
                let (local_log, rp) = if n < 0 {
                    (height, vec![r[0].exp_power_of_2((-n) as usize)])
                } else {
                    (l, r[..=lift].to_vec())
                };
                let a = F::from_u32(17);
                let b = F::from_u32(29);
                let value = eval_eq_mle(&u[1 + lift..], &bits)
                    * eval_in_uni(l, n, u[0])
                    * (a * eval_eq_prism(local_log, &u[..=lift], &rp)
                        + b * eval_rot_kernel_prism(local_log, &u[..=lift], &rp));
                rows.push(format!("{{\"l\":{l},\"stack\":{stack},\"height\":{height},\"start\":{start},\"omega\":{},\"value\":{}}}",F::two_adic_generator(l).as_canonical_u32(),value.as_canonical_u32()));
            }
        }
    }
    std::fs::write(
        "/tmp/nearproof-stack-kernel-oracle.json",
        format!("[{}]\n", rows.join(",")),
    )
    .unwrap();
}

#[test]
fn nearproof_reconstruct_internal_witness() {
    use std::io::Write;

    use openvm_stark_backend::{
        codec::{Decode, Encode},
        proof::Proof,
        prover::{MatrixDimensions, TraceCommitter},
    };
    use openvm_stark_sdk::config::{
        app_params_with_100_bits_security, internal_params_with_100_bits_security,
        leaf_params_with_100_bits_security,
    };
    use p3_field::PrimeField32;
    let app =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(app_params_with_100_bits_security(12));
    let fib = FibFixture::new_with_num_airs(0, 1, 1 << 8, 9);
    let (app_vk, _) = fib.keygen_and_prove(&app);
    let leaf_engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(leaf_params_with_100_bits_security());
    let (_, leaf_pk) = verifier_circuit_keygen::<2>(&leaf_engine, &app_vk);
    let leaf_vk = leaf_pk.get_vk();
    let bytes = std::fs::read("/tmp/nearproof-chain-leaf.proof").unwrap();
    let mut reader = bytes.as_slice();
    let leaf = Proof::<BabyBearPoseidon2Config>::decode(&mut reader).unwrap();
    assert!(reader.is_empty());
    leaf_engine.verify(&leaf_vk, &leaf).unwrap();
    let engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(internal_params_with_100_bits_security());
    let (circuit, pk) = verifier_circuit_keygen::<2>(&engine, &leaf_vk);
    let vk = pk.get_vk();
    let bytes = std::fs::read("/tmp/nearproof-native-internal.proof").unwrap();
    let mut reader = bytes.as_slice();
    let proof = Proof::<BabyBearPoseidon2Config>::decode(&mut reader).unwrap();
    assert!(reader.is_empty());
    engine.verify(&vk, &proof).unwrap();
    let ctxs = circuit.generate_proving_ctxs_base(
        &leaf_vk,
        CachedTraceCtx::PcsData(circuit.commit_child_vk(&engine, &leaf_vk)),
        &[leaf],
        &(),
        default_duplex_sponge_recorder(),
    );
    let mut ids = (0..ctxs.len())
        .filter(|&i| proof.trace_vdata[i].is_some())
        .collect_vec();
    ids.sort_by_key(|&i| {
        (
            std::cmp::Reverse(proof.trace_vdata[i].as_ref().unwrap().log_height),
            i,
        )
    });
    for &i in &ids {
        let ctx = &ctxs[i];
        let vd = proof.trace_vdata[i].as_ref().unwrap();
        assert_eq!(ctx.common_main.height(), 1 << vd.log_height);
        assert_eq!(ctx.public_values, proof.public_values[i]);
        assert_eq!(ctx.cached_mains.len(), vd.cached_commitments.len());
        assert!(vk.inner.per_air[i].preprocessed_data.is_none());
        for (cache, commitment) in ctx.cached_mains.iter().zip(&vd.cached_commitments) {
            assert_eq!(cache.commitment, *commitment);
            let (recomputed, _) = engine.device().commit(&[&cache.trace]).unwrap();
            assert_eq!(recomputed, *commitment);
        }
    }
    let traces = ids.iter().map(|&i| &ctxs[i].common_main).collect_vec();
    let (commitment, _) = engine.device().commit(&traces).unwrap();
    let original_commitment_matches = commitment == proof.common_main_commit;
    println!("NEARPROOF_ORIGINAL_COMMITMENT_MATCH={original_commitment_matches}");
    // Persist a new proof made from these exact contexts. The old proof is not replaced.
    let d_pk = engine.device().transport_pk_to_device(&pk);
    let fresh_ctxs = ctxs
        .iter()
        .enumerate()
        .map(|(i, c)| {
            (
                i,
                AirProvingContext {
                    cached_mains: c.cached_mains.clone(),
                    common_main: c.common_main.clone(),
                    public_values: c.public_values.clone(),
                },
            )
        })
        .collect();
    let fresh = engine
        .prove(&d_pk, ProvingContext::new(fresh_ctxs))
        .unwrap();
    engine.verify(&vk, &fresh).unwrap();
    assert_eq!(commitment, fresh.common_main_commit);
    let mut fresh_bytes = Vec::new();
    fresh.encode(&mut fresh_bytes).unwrap();
    std::fs::write("/tmp/nearproof-witness-internal.proof", fresh_bytes).unwrap();
    let dir = "/tmp/nearproof-reconstructed-witness";
    std::fs::create_dir_all(dir).unwrap();
    let mut rows = Vec::new();
    for &i in &ids {
        let matrices = std::iter::once(&ctxs[i].common_main)
            .chain(ctxs[i].cached_mains.iter().map(|c| &c.trace));
        for (part, matrix) in matrices.enumerate() {
            let name = format!("air-{i}-part-{part}.bin");
            let mut file =
                std::io::BufWriter::new(std::fs::File::create(format!("{dir}/{name}")).unwrap());
            for x in &matrix.values {
                file.write_all(&x.as_canonical_u32().to_le_bytes()).unwrap();
            }
            file.flush().unwrap();
            rows.push(format!(
                "{{\"air\":{i},\"part\":{part},\"height\":{},\"width\":{},\"file\":\"{name}\"}}",
                matrix.height(),
                matrix.width()
            ));
        }
    }
    std::fs::write(
        format!("{dir}/manifest.json"),
        format!("[{}]\n", rows.join(",")),
    )
    .unwrap();
    println!(
        "NEARPROOF_FRESH_WITNESS common_and_cached_commitments_match=true matrices={}",
        rows.len()
    );
}

#[test]
fn nearproof_check_saved_witness_openings() {
    use openvm_stark_backend::prover::poly::evals_eq_hyperprism;
    use openvm_stark_sdk::config::baby_bear_poseidon2::{EF, F};
    use p3_field::{BasedVectorSpace, PrimeCharacteristicRing, TwoAdicField};
    fn words(path: &str) -> Vec<u32> {
        let b = std::fs::read(path).unwrap();
        assert_eq!(b.len() % 4, 0);
        b.chunks_exact(4)
            .map(|x| u32::from_le_bytes(x.try_into().unwrap()))
            .collect()
    }
    fn ext(it: &mut impl Iterator<Item = u32>) -> EF {
        EF::from_basis_coefficients_fn(|_| {
            let x = it.next().unwrap();
            assert!(x < 2013265921);
            F::from_u32(x)
        })
    }
    let dir = "/tmp/nearproof-reconstructed-witness";
    let mut input = words(&format!("{dir}/opening-check.bin")).into_iter();
    let lskip = input.next().unwrap() as usize;
    let rlen = input.next().unwrap() as usize;
    let r = (0..rlen).map(|_| ext(&mut input)).collect_vec();
    let count = input.next().unwrap();
    let mut checked = 0;
    for _ in 0..count {
        let air = input.next().unwrap();
        let part = input.next().unwrap();
        let height = input.next().unwrap() as usize;
        let width = input.next().unwrap() as usize;
        let rotated = input.next().unwrap() != 0;
        let nclaims = input.next().unwrap() as usize;
        let claims = (0..nclaims).map(|_| ext(&mut input)).collect_vec();
        assert_eq!(nclaims, width * (1 + usize::from(rotated)));
        let values = words(&format!("{dir}/air-{air}-part-{part}.bin"));
        assert_eq!(values.len(), height * width);
        assert!(values.iter().all(|x| *x < 2013265921));
        let log = height.ilog2() as usize;
        assert_eq!(1 << log, height);
        let local = log.min(lskip);
        let lift = log.saturating_sub(lskip);
        let z = r[0].exp_power_of_2(lskip.saturating_sub(log));
        let omega = F::two_adic_generator(local)
            .powers()
            .take(1 << local)
            .collect_vec();
        let weights = evals_eq_hyperprism(&omega, z, &r[1..1 + lift]);
        let mut current = vec![EF::ZERO; width];
        let mut next = vec![EF::ZERO; width];
        for row in 0..height {
            for col in 0..width {
                current[col] += weights[row] * F::from_u32(values[row * width + col]);
                if rotated {
                    next[col] +=
                        weights[row] * F::from_u32(values[((row + 1) % height) * width + col]);
                }
            }
        }
        for col in 0..width {
            assert_eq!(
                current[col],
                claims[col * (1 + usize::from(rotated))],
                "air {air} part {part} col {col}"
            );
            checked += 1;
            if rotated {
                assert_eq!(next[col], claims[2 * col + 1]);
                checked += 1;
            }
        }
    }
    assert!(input.next().is_none());
    println!("NEARPROOF_WITNESS_OPENINGS checked={checked} matrices={count}");
}

#[test]
fn nearproof_weighted_native_sumcheck() {
    use openvm_cpu_backend::StackedReductionCpuNew;
    use openvm_stark_backend::{
        codec::Decode,
        proof::Proof,
        prover::{
            poly::evals_eq_hyperprism, stacked_reduction::StackedReductionProver, TraceCommitter,
        },
        FiatShamirTranscript,
    };
    use openvm_stark_sdk::config::{
        baby_bear_poseidon2::{EF, F},
        internal_params_with_100_bits_security,
    };
    use p3_field::{BasedVectorSpace, PrimeCharacteristicRing, TwoAdicField};
    use p3_matrix::dense::RowMajorMatrix;
    fn words(path: &str) -> Vec<u32> {
        let b = std::fs::read(path).unwrap();
        assert_eq!(b.len() % 4, 0);
        b.chunks_exact(4)
            .map(|x| u32::from_le_bytes(x.try_into().unwrap()))
            .collect()
    }
    fn ext(it: &mut impl Iterator<Item = u32>) -> EF {
        EF::from_basis_coefficients_fn(|_| {
            let x = it.next().unwrap();
            assert!(x < 2013265921);
            F::from_u32(x)
        })
    }
    fn enc(xs: &[EF]) -> String {
        format!(
            "[{}]",
            xs.iter()
                .map(|x| format!(
                    "{:?}",
                    <EF as BasedVectorSpace<F>>::as_basis_coefficients_slice(x)
                ))
                .join(",")
        )
    }
    let dir = "/tmp/nearproof-reconstructed-witness";
    let mut input = words(&format!("{dir}/weighted-input.bin")).into_iter();
    let lskip = input.next().unwrap() as usize;
    let nstack = input.next().unwrap() as usize;
    let rlen = input.next().unwrap() as usize;
    let r = (0..rlen).map(|_| ext(&mut input)).collect_vec();
    let claim = ext(&mut input);
    let count = input.next().unwrap() as usize;
    let pairs = (0..count)
        .map(|_| [ext(&mut input), ext(&mut input)])
        .collect_vec();
    assert!(input.next().is_none());
    let mut meta = words(&format!("{dir}/opening-check.bin")).into_iter();
    assert_eq!(meta.next().unwrap() as usize, lskip);
    let nr = meta.next().unwrap() as usize;
    for _ in 0..nr {
        let _ = ext(&mut meta);
    }
    let nm = meta.next().unwrap();
    let mut common = Vec::new();
    let mut other = Vec::new();
    let mut cached_airs = Vec::new();
    for _ in 0..nm {
        let air = meta.next().unwrap() as usize;
        let part = meta.next().unwrap();
        let height = meta.next().unwrap() as usize;
        let width = meta.next().unwrap() as usize;
        meta.next().unwrap();
        let nc = meta.next().unwrap();
        for _ in 0..nc {
            let _ = ext(&mut meta);
        }
        let values = words(&format!("{dir}/air-{air}-part-{part}.bin"));
        assert_eq!(values.len(), height * width);
        assert!(values.iter().all(|&x| x < 2013265921));
        let m = RowMajorMatrix::new(values.into_iter().map(F::from_u32).collect(), width);
        if part == 0 {
            common.push(m);
        } else {
            assert_eq!(part, 1);
            other.push(m);
            cached_airs.push(air);
        }
    }
    assert!(meta.next().is_none());
    let engine =
        BabyBearPoseidon2CpuEngine::<DuplexSponge>::new(internal_params_with_100_bits_security());
    assert_eq!(engine.device().params().l_skip, lskip);
    assert_eq!(engine.device().params().n_stack, nstack);
    let bytes = std::fs::read("/tmp/nearproof-witness-internal.proof").unwrap();
    let mut reader = bytes.as_slice();
    let original = Proof::<BabyBearPoseidon2Config>::decode(&mut reader).unwrap();
    assert!(reader.is_empty());
    let (commit, data) = engine
        .device()
        .commit(&common.iter().collect_vec())
        .unwrap();
    assert_eq!(commit, original.common_main_commit);
    let mut commitments = vec![commit];
    let mut datas = vec![data];
    for (air, matrix) in cached_airs.iter().zip(&other) {
        let (commit, data) = engine.device().commit(&[matrix]).unwrap();
        assert_eq!(
            commit,
            original.trace_vdata[*air]
                .as_ref()
                .unwrap()
                .cached_commitments[0]
        );
        commitments.push(commit);
        datas.push(data);
    }
    let need_rot = datas
        .iter()
        .map(|d| vec![true; d.layout.mat_starts.len()])
        .collect_vec();
    let mut prover = StackedReductionCpuNew::<BabyBearPoseidon2Config>::new(
        engine.device(),
        datas.iter().collect(),
        need_rot,
        &r,
        EF::ONE,
    );
    prover.nearproof_replace_column_weights(&pairs);
    let mut transcript = default_duplex_sponge_recorder();
    // Diagnostic standalone transcript. Fixed statement precedes all round messages.
    let mut seed = vec![
        EF::from_u32(20261017),
        EF::from_usize(lskip),
        EF::from_usize(nstack),
        EF::from_usize(rlen),
        claim,
    ];
    seed.extend(&r);
    seed.push(EF::from_usize(pairs.len()));
    seed.extend(pairs.iter().flatten().copied());
    for c in &commitments {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_commit(&mut transcript, *c);
    }
    for x in &seed {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut transcript, *x);
    }
    let s0 = prover.batch_sumcheck_uni_round0_poly();
    assert_eq!(s0.coeffs().len(), 2 * ((1 << lskip) - 1) + 1);
    assert_eq!(
        s0.coeffs().iter().step_by(1 << lskip).copied().sum::<EF>() * F::from_usize(1 << lskip),
        claim
    );
    for x in s0.coeffs() {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut transcript, *x);
    }
    let mut u = vec![FiatShamirTranscript::<BabyBearPoseidon2Config>::sample_ext(
        &mut transcript,
    )];
    prover.fold_ple_evals(u[0]);
    let mut rounds = Vec::new();
    for round in 1..=nstack {
        let poly = prover.batch_sumcheck_poly_eval(round, u[round - 1]);
        for x in poly {
            FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut transcript, x);
        }
        let challenge =
            FiatShamirTranscript::<BabyBearPoseidon2Config>::sample_ext(&mut transcript);
        u.push(challenge);
        rounds.push(poly);
        prover.fold_mle_evals(round, challenge);
    }
    let openings = prover.into_stacked_openings();
    // Re-evaluate stacked source matrices independently of the prover's folding code.
    let omega = F::two_adic_generator(lskip)
        .powers()
        .take(1 << lskip)
        .collect_vec();
    let weights = evals_eq_hyperprism(&omega, u[0], &u[1..]);
    let mut checked = 0;
    for (d, claims) in datas.iter().zip(&openings) {
        assert_eq!(claims.len(), d.layout.width());
        for (col, expected) in claims.iter().enumerate() {
            let column = &d.matrix.values[col * weights.len()..(col + 1) * weights.len()];
            let actual = column
                .iter()
                .zip(&weights)
                .map(|(&v, &w)| w * v)
                .sum::<EF>();
            assert_eq!(actual, *expected);
            checked += 1;
        }
    }
    // Fresh transcript receiver checks challenge chronology independently.
    let mut receiver = default_duplex_sponge_recorder();
    for c in &commitments {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_commit(&mut receiver, *c);
    }
    for x in &seed {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut receiver, *x);
    }
    for x in s0.coeffs() {
        FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut receiver, *x);
    }
    assert_eq!(
        FiatShamirTranscript::<BabyBearPoseidon2Config>::sample_ext(&mut receiver),
        u[0]
    );
    for (i, poly) in rounds.iter().enumerate() {
        for x in poly {
            FiatShamirTranscript::<BabyBearPoseidon2Config>::observe_ext(&mut receiver, *x);
        }
        assert_eq!(
            FiatShamirTranscript::<BabyBearPoseidon2Config>::sample_ext(&mut receiver),
            u[i + 1]
        );
    }
    let body=format!("{{\"s0\":{},\"rounds\":[{}],\"u\":{},\"openings\":[{}],\"claim\":{},\"r\":{},\"matrix_openings_checked\":{checked}}}\n",
        enc(s0.coeffs()),rounds.iter().map(|x|enc(x)).join(","),enc(&u),openings.iter().map(|x|enc(x)).join(","),enc(&[claim]),enc(&r));
    std::fs::write("/tmp/nearproof-weighted-sumcheck.json", body).unwrap();
    println!("NEARPROOF_WEIGHTED_SUMCHECK rounds={} extension_elements={} matrix_openings_checked={checked}",nstack,s0.coeffs().len()+2*nstack+checked);
}
