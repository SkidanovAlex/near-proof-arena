//! Diagnostic fixed SHA384 graph. Shape and literal bytes are verifier-key data.
use std::{collections::BTreeMap, path::PathBuf};
use anyhow::{ensure, Result};
use binius_circuits::sha512::nearproof_sha384_fixed;
use binius_core::word::Word;
use binius_frontend::{CircuitBuilder, Wire, WitnessFiller};
use clap::Args;
use serde_json::Value;
use sha2::{Digest, Sha384};
use crate::ExampleCircuit;

#[derive(Args, Debug, Clone)]
pub struct GraphParams { #[arg(long)] pub graph: PathBuf }
#[derive(Args, Debug, Clone)]
pub struct GraphInstance {}
pub struct NearproofHashGraph {
    graph: Value,
    inputs: BTreeMap<String,Vec<Wire>>,
    outputs: Vec<(usize,[Wire;6])>,
}
fn constant_bytes(b: &CircuitBuilder, x: &[u8]) -> Vec<Wire> {
    x.iter().map(|v|b.add_constant(Word(*v as u64))).collect()
}
fn bytes(b: &CircuitBuilder, words: &[Wire], n: usize) -> Vec<Wire> {
    let mask=b.add_constant(Word(255));
    (0..n).map(|i|b.band(b.shr(words[i/8],(56-8*(i%8)) as u32),mask)).collect()
}
fn words(b: &CircuitBuilder, data: &[Wire]) -> Vec<Wire> {
    data.chunks(8).map(|chunk|b.bxor_multi(&chunk.iter().enumerate().map(|(i,x)|b.shl(*x,(56-8*i) as u32)).collect::<Vec<_>>())).collect()
}
impl ExampleCircuit for NearproofHashGraph {
    type Params=GraphParams;
    type Instance=GraphInstance;
    fn build(params: GraphParams,b: &mut CircuitBuilder) -> Result<Self> {
        let graph:Value=serde_json::from_slice(&std::fs::read(params.graph)?)?;
        let mut inputs=BTreeMap::new();let mut input_bytes=BTreeMap::new();
        for (name,value) in graph["inputs"].as_object().unwrap() {
            let n=hex::decode(value.as_str().unwrap())?.len();
            let wires=(0..n.div_ceil(8)).map(|_|b.add_inout()).collect::<Vec<_>>();
            input_bytes.insert(name.clone(),bytes(b,&wires,n));inputs.insert(name.clone(),wires);
        }
        let nodes=graph["nodes"].as_array().unwrap();ensure!(!nodes.is_empty(),"empty graph");
        let mut hashes:Vec<[Wire;6]>=Vec::new();let mut outputs=Vec::new();
        for (index,node) in nodes.iter().enumerate() {
            let tag=node["tag"].as_str().unwrap().as_bytes();let parts=node["parts"].as_array().unwrap();
            let mut header=b"NEAR-PQ384-PRIMITIVES-V1".to_vec();header.extend((tag.len() as u32).to_le_bytes());header.extend(tag);header.extend((parts.len() as u32).to_le_bytes());
            let mut message=constant_bytes(b,&header);
            for part in parts {
                let data=match part[0].as_str().unwrap() {
                    "literal"=>constant_bytes(b,&hex::decode(part[1].as_str().unwrap())?),
                    "input"=>input_bytes.get(part[1].as_str().unwrap()).unwrap().clone(),
                    "hash"=>{let j=part[1].as_u64().unwrap() as usize;ensure!(j<index,"forward hash edge");bytes(b,&hashes[j],48)},
                    _=>anyhow::bail!("unknown reference"),
                };
                message.extend(constant_bytes(b,&(data.len() as u64).to_le_bytes()));message.extend(data);
            }
            let digest=nearproof_sha384_fixed(b,&words(b,&message),message.len());
            if node["tag"]=="transcript/squeeze" || index+1==nodes.len() {
                let public=std::array::from_fn(|_|b.add_inout());
                for i in 0..6 {b.assert_eq(format!("node[{index}].digest[{i}]"),digest[i],public[i]);}
                outputs.push((index,public));
            }
            hashes.push(digest);
        }
        Ok(Self{graph,inputs,outputs})
    }
    fn populate_witness(&self,_:GraphInstance,w:&mut WitnessFiller<'_>) -> Result<()> {
        let mut inputs=BTreeMap::new();
        for (name,value) in self.graph["inputs"].as_object().unwrap() {inputs.insert(name.clone(),hex::decode(value.as_str().unwrap())?);}
        if std::env::var_os("NEARPROOF_GRAPH_BAD_INPUT").is_some() {
            let first=inputs.values_mut().find(|v|!v.is_empty()).unwrap();first[0]^=1;
        }
        for (name,data) in &inputs {
            for (wire,chunk) in self.inputs[name].iter().zip(data.chunks(8)) {
                let mut word=[0u8;8];word[..chunk.len()].copy_from_slice(chunk);w[*wire]=Word(u64::from_be_bytes(word));
            }
        }
        let mut hashes:Vec<Vec<u8>>=Vec::new();
        for node in self.graph["nodes"].as_array().unwrap() {
            let tag=node["tag"].as_str().unwrap().as_bytes();let parts=node["parts"].as_array().unwrap();
            let mut frame=b"NEAR-PQ384-PRIMITIVES-V1".to_vec();frame.extend((tag.len() as u32).to_le_bytes());frame.extend(tag);frame.extend((parts.len() as u32).to_le_bytes());
            for part in parts {
                let data=match part[0].as_str().unwrap() {
                    "literal"=>hex::decode(part[1].as_str().unwrap())?,
                    "input"=>inputs[part[1].as_str().unwrap()].clone(),
                    "hash"=>hashes[part[1].as_u64().unwrap() as usize].clone(),
                    _=>unreachable!(),
                };
                frame.extend((data.len() as u64).to_le_bytes());frame.extend(data);
            }
            hashes.push(Sha384::digest(frame).to_vec());
        }
        for (index,public) in &self.outputs {
            for (wire,chunk) in public.iter().zip(hashes[*index].chunks_exact(8)) {w[*wire]=Word(u64::from_be_bytes(chunk.try_into().unwrap()));}
        }
        Ok(())
    }
}
