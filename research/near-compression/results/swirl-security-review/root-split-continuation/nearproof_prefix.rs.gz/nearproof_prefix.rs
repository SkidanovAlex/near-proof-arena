//! Diagnostic key-directed prefix codec. No column openings or old PCS tail.
use std::io::{Error, Read, Result};

use itertools::Itertools;
use openvm_stark_backend::{
    calculate_n_logup,
    codec::{DecodableConfig, Decode, EncodableConfig, Encode},
    keygen::types::MultiStarkVerifyingKey,
    proof::{
        BatchConstraintProof, GkrLayerClaims, GkrProof, Proof, StackingProof, TraceVData, WhirProof,
    },
    verifier::proof_shape::verify_proof_shape,
};
use openvm_stark_sdk::config::baby_bear_poseidon2::{BabyBearPoseidon2Config as SC, EF, F};
use p3_field::PrimeCharacteristicRing;
const MAGIC: &[u8; 8] = b"NPREF001";
fn require(ok: bool, msg: &str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(Error::other(msg))
    }
}

pub struct Prefix {
    commit: <SC as openvm_stark_backend::StarkProtocolConfig>::Digest,
    traces: Vec<Option<TraceVData<SC>>>,
    public: Vec<Vec<F>>,
    gkr: GkrProof<SC>,
    batch: BatchConstraintProof<SC>, // column_openings ALWAYS empty in this type
}

pub fn encode(p: &Proof<SC>, vk: &MultiStarkVerifyingKey<SC>) -> Result<Vec<u8>> {
    require(p.trace_vdata.len() == vk.inner.per_air.len(), "AIR count")?;
    let mut b = MAGIC.to_vec();
    SC::encode_digest(&p.common_main_commit, &mut b)?;
    for ((data, pv), key) in p
        .trace_vdata
        .iter()
        .zip(&p.public_values)
        .zip(&vk.inner.per_air)
    {
        require(
            key.preprocessed_data.is_none(),
            "preprocessed unsupported in diagnostic profile",
        )?;
        u8::from(data.is_some()).encode(&mut b)?;
        if let Some(d) = data {
            (d.log_height as u32).encode(&mut b)?;
            for c in &d.cached_commitments {
                SC::encode_digest(c, &mut b)?;
            }
            for v in pv {
                SC::encode_base_field(v, &mut b)?;
            }
        }
    }
    SC::encode_base_field(&p.gkr_proof.logup_pow_witness, &mut b)?;
    SC::encode_extension_field(&p.gkr_proof.q0_claim, &mut b)?;
    for c in &p.gkr_proof.claims_per_layer {
        c.encode(&mut b)?;
    }
    for row in &p.gkr_proof.sumcheck_polys {
        for vals in row {
            SC::encode_extension_field_iter(vals.iter(), &mut b)?;
        }
    }
    for xs in [
        &p.batch_constraint_proof.numerator_term_per_air,
        &p.batch_constraint_proof.denominator_term_per_air,
        &p.batch_constraint_proof.univariate_round_coeffs,
    ] {
        SC::encode_extension_field_iter(xs.iter(), &mut b)?;
    }
    for row in &p.batch_constraint_proof.sumcheck_round_polys {
        SC::encode_extension_field_iter(row.iter(), &mut b)?;
    }
    Ok(b)
}

pub fn decode(bytes: &[u8], vk: &MultiStarkVerifyingKey<SC>) -> Result<Prefix> {
    let mut r = bytes;
    let mut magic = [0u8; 8];
    r.read_exact(&mut magic)?;
    require(&magic == MAGIC, "prefix version")?;
    let commit = SC::decode_digest(&mut r)?;
    let mut traces = Vec::new();
    let mut public = Vec::new();
    let l = vk.inner.params.l_skip;
    let max_height = l + vk.inner.params.n_stack;
    require(max_height < usize::BITS as usize, "height profile overflow")?;
    for key in &vk.inner.per_air {
        require(
            key.preprocessed_data.is_none(),
            "preprocessed unsupported in diagnostic profile",
        )?;
        let present = u8::decode(&mut r)?;
        require(present <= 1, "presence tag")?;
        if present == 0 {
            require(!key.is_required, "required AIR absent")?;
            traces.push(None);
            public.push(Vec::new());
        } else {
            let h = u32::decode(&mut r)? as usize;
            require(h <= max_height, "trace height")?;
            let cached = (0..key.params.width.cached_mains.len())
                .map(|_| SC::decode_digest(&mut r))
                .collect::<Result<Vec<_>>>()?;
            let pv = (0..key.params.num_public_values)
                .map(|_| SC::decode_base_field(&mut r))
                .collect::<Result<Vec<_>>>()?;
            traces.push(Some(TraceVData {
                log_height: h,
                cached_commitments: cached,
            }));
            public.push(pv);
        }
    }
    let ids = (0..traces.len())
        .filter(|&i| traces[i].is_some())
        .sorted_by_key(|&i| (std::cmp::Reverse(traces[i].as_ref().unwrap().log_height), i))
        .collect_vec();
    require(!ids.is_empty(), "empty traces")?;
    for constraint in &vk.inner.trace_height_constraints {
        let sum = ids
            .iter()
            .map(|&i| {
                (1u128 << traces[i].as_ref().unwrap().log_height.max(l))
                    * constraint.coefficients[i] as u128
            })
            .sum::<u128>();
        require(
            sum < constraint.threshold as u128,
            "trace height constraint",
        )?;
    }
    let total = ids
        .iter()
        .map(|&i| {
            (vk.inner.per_air[i].num_interactions() as u128)
                << traces[i].as_ref().unwrap().log_height.max(l)
        })
        .sum::<u128>();
    require(total <= u64::MAX as u128, "interaction overflow")?;
    let rounds = if total == 0 {
        0
    } else {
        l + calculate_n_logup(l, total as u64)
    };
    let logup_pow_witness = SC::decode_base_field(&mut r)?;
    let q0_claim = SC::decode_extension_field(&mut r)?;
    let claims_per_layer = (0..rounds)
        .map(|_| GkrLayerClaims::<SC>::decode(&mut r))
        .collect::<Result<Vec<_>>>()?;
    let mut sumcheck_polys = Vec::new();
    for n in 1..rounds {
        let mut row = Vec::new();
        for _ in 0..n {
            row.push([
                SC::decode_extension_field(&mut r)?,
                SC::decode_extension_field(&mut r)?,
                SC::decode_extension_field(&mut r)?,
            ]);
        }
        sumcheck_polys.push(row);
    }
    let num = SC::decode_extension_field_n(&mut r, ids.len())?;
    let den = SC::decode_extension_field_n(&mut r, ids.len())?;
    let degree = vk.inner.max_constraint_degree() + 1;
    let uni = SC::decode_extension_field_n(&mut r, degree * ((1 << l) - 1) + 1)?;
    let n = traces[ids[0]]
        .as_ref()
        .unwrap()
        .log_height
        .saturating_sub(l);
    let polys = (0..n)
        .map(|_| SC::decode_extension_field_n(&mut r, degree))
        .collect::<Result<Vec<_>>>()?;
    require(r.is_empty(), "trailing prefix bytes")?;
    Ok(Prefix {
        commit,
        traces,
        public,
        gkr: GkrProof {
            logup_pow_witness,
            q0_claim,
            claims_per_layer,
            sumcheck_polys,
        },
        batch: BatchConstraintProof {
            numerator_term_per_air: num,
            denominator_term_per_air: den,
            univariate_round_coeffs: uni,
            sumcheck_round_polys: polys,
            column_openings: Vec::new(),
        },
    })
}

impl Prefix {
    /// Zero column values are shape placeholders ONLY, never verified as openings.
    pub fn shape_adapter(
        mut self,
        vk: &MultiStarkVerifyingKey<SC>,
        stacking: StackingProof<SC>,
        whir: WhirProof<SC>,
    ) -> Result<Proof<SC>> {
        let ids = (0..self.traces.len())
            .filter(|&i| self.traces[i].is_some())
            .sorted_by_key(|&i| {
                (
                    std::cmp::Reverse(self.traces[i].as_ref().unwrap().log_height),
                    i,
                )
            })
            .collect_vec();
        for i in ids {
            let key = &vk.inner.per_air[i];
            let stride = if key.params.need_rot { 2 } else { 1 };
            self.batch.column_openings.push(
                std::iter::once(key.params.width.common_main)
                    .chain(key.params.width.cached_mains.iter().copied())
                    .map(|w| vec![EF::ZERO; w * stride])
                    .collect(),
            );
        }
        let proof = Proof {
            common_main_commit: self.commit,
            trace_vdata: self.traces,
            public_values: self.public,
            gkr_proof: self.gkr,
            batch_constraint_proof: self.batch,
            stacking_proof: stacking,
            whir_proof: whir,
        };
        verify_proof_shape(&vk.inner, &proof).map_err(|e| Error::other(e.to_string()))?;
        Ok(proof)
    }
}
