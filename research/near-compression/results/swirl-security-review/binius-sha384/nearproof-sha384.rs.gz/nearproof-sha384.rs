use anyhow::{ensure, Result};
use binius_circuits::sha512::nearproof_sha384_fixed;
use binius_core::word::Word;
use binius_frontend::{CircuitBuilder, Wire, WitnessFiller};
use sha2::Digest;
use super::utils::{self, HasherInstance, HasherMode, HasherParams};
use crate::ExampleCircuit;

pub struct NearproofSha384 { message: Vec<Wire>, digest: [Wire; 6], mode: HasherMode }
impl ExampleCircuit for NearproofSha384 {
    type Params = HasherParams;
    type Instance = HasherInstance;
    fn build(params: HasherParams, builder: &mut CircuitBuilder) -> Result<Self> {
        let mode = utils::resolve_hasher_mode(&params, "SHA384", false)?;
        let HasherMode::Fixed { len_bytes } = mode else { unreachable!() };
        let message = (0..len_bytes.div_ceil(8)).map(|_| builder.add_inout()).collect::<Vec<_>>();
        let result = nearproof_sha384_fixed(builder, &message, len_bytes);
        let digest = std::array::from_fn(|_| builder.add_inout());
        for i in 0..6 { builder.assert_eq(format!("sha384[{i}]"), result[i], digest[i]); }
        Ok(Self { message, digest, mode })
    }
    fn populate_witness(&self, instance: HasherInstance, w: &mut WitnessFiller<'_>) -> Result<()> {
        let message = if let Ok(path) = std::env::var("NEARPROOF_SHA384_MESSAGE") {
            std::fs::read(path)?
        } else { utils::resolve_hasher_message(&self.mode, &instance)? };
        ensure!(message.len() == self.mode.capacity_bytes(), "fixed message length");
        let digest = sha2::Sha384::digest(&message);
        for (wire,word) in self.message.iter().zip(utils::pack_bytes_u64words(&message,true)) { w[*wire]=word; }
        for (i,word) in digest.chunks_exact(8).enumerate() {
            let mut value=u64::from_be_bytes(word.try_into().unwrap());
            if i==0 && std::env::var_os("NEARPROOF_BAD_SHA384_DIGEST").is_some() { value^=1; }
            w[self.digest[i]]=Word(value);
        }
        Ok(())
    }
    fn param_summary(params: &Self::Params) -> Option<String> { utils::hasher_param_summary(params) }
}
